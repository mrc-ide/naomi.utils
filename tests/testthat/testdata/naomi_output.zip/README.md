### Naomi output file directory

    ## .
    ## ├── art_attendance.csv
    ## ├── boundaries.geojson
    ## ├── fit
    ## │   ├── calibration_options.yml
    ## │   ├── data_options.yml
    ## │   ├── model_options.yml
    ## │   └── spectrum_calibration.csv
    ## ├── indicators.csv
    ## ├── info
    ## │   ├── inputs.csv
    ## │   ├── options.yml
    ## │   ├── packages.csv
    ## │   └── unaids_navigator_checklist.csv
    ## ├── inputs_outputs.csv
    ## ├── meta_age_group.csv
    ## ├── meta_area.csv
    ## ├── meta_indicator.csv
    ## ├── meta_period.csv
    ## └── pepfar_datapack_indicators_2025.csv

The following files have been generated as part of a Naomi model fit:

**fit**:

-   calibration\_options.yml: Specifications for calibration of Naomi
    estimates to Spectrum totals.
-   data\_options.yml: Specifications for inclusion of model inputs.
-   model\_options.yml: Specfications for model fit parameters.
-   spectrum\_calibration: Tabular dataset of calibrated and an
    uncalibrated model outputs.

**info**:

-   unaids\_navigator\_checklist: Navigator checklist.
-   model\_options.yml: Full model options (including advanced options).

Files containing naomi model outputs:

-   indicators.csv: Naomi model outputs.
-   art\_attendance.csv: Tabular dataset of ART patient movement between
    neighbouring admin areas.
-   inputs\_outputs.csv: Model data inputs aligned with model estimates.
-   pepfar\_datapack\_indicators.csv: PEPFAR district-level datapack
    extract

Metadata on naomi model specifications:

-   boundaries.geojson: Boundary file used in model fit.
-   meta\_age\_group.csv: Age stratification inlcuded in model fit.
-   meta\_area.csv: Admin areas inlcuded in model fit.
-   meta\_period: Time periods included in model fit.
